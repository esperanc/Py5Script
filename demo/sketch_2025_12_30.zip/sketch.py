"""
Alexandre Villares
Sketch a day for 12/30/2025 ported to Py5Script
See https://github.com/villares/sketch-a-day/tree/main/2025/sketch_2025_12_30
"""

from itertools import product

import numpy as np

drag = None
W, H = 100., 100.
M = 100
PTS = np.array([
    np.array((M - W, M - H)),     
    np.array((M + W, M - H)),     
    np.array((M + W, M + H)),     
    np.array((M - W, M + H)),     
])
pts = PTS.copy()

def setup():
    createCanvas (600, 600)
    m = np.array((mouse_x, mouse_y))
    pm = np.array((20, 20))

def draw():
    background(0)
    no_fill() 
    stroke_weight(2)
    stroke(255)
    translate(width / 2, height / 2)
    for angle in range(0, 360, 18):  # I forgot to convert to radians!
        # will do it tomorrow :)
        angle = radians(angle)
        R = np.array(((np.cos(angle), -np.sin(angle)),
                      (np.sin(angle),  np.cos(angle))))
        begin_shape()
        for x,y in pts @ R: 
            vertex(x,y)
        end_shape(CLOSE)
    stroke_weight(10)
    for x, y in pts:
        if mouse_over(x, y):
            stroke(200, 200, 0)
        else:
            stroke(0, 200, 200)
        point(x, y)
  
def mouse_over(x, y, radius=10):
    return dist(
        x, y, mouse_x - width / 2, mouse_y -height / 2) < radius
  
def mouse_pressed():
    global drag
    if drag is None:
        for i, (x, y) in enumerate(pts):
            if mouse_over(x, y):
                drag = i
                break
            
def mouse_dragged():
    if drag is not None:
        m = np.array((mouse_x, mouse_y))
        pm = np.array((pmouse_x, pmouse_y))
        delta =  m - pm 
        pts[drag] += delta 
        
    
def mouse_released():
    global drag
    drag = None
     
def key_pressed():
    if key == ' ':
        pts[:] = PTS
    