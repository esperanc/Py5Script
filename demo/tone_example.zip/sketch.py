# Tone.js demo — loaded via js_modules.txt
# Click anywhere to play a note

synth = None

def setup():
    create_canvas(400, 200)
    background(30)
    fill(255)
    text_align(CENTER, CENTER)
    text_size(18)
    text("Click to play a note", width / 2, height / 2)

def mouse_pressed():
    global synth

    # Tone.start() must be called after a user gesture (browser autoplay policy)
    Tone.start()

    if synth is None:
        synth = Tone.Synth.new()
        synth.toDestination()

    notes = ["C4", "D4", "E4", "F4", "G4", "A4", "B4", "C5"]
    note = notes[int(P5.random(len(notes)))]
    synth.triggerAttackRelease(note, "8n")

    background(30)
    fill(100, 200, 255)
    text_align(CENTER, CENTER)
    text_size(24)
    text(f"♪ {note}", width / 2, height / 2)
