def setup():
    createCanvas(400, 400)
    global gui, config
    gui = lil.GUI.new()
    config = js_object({
        "number" : 100,
        "text" : "text",
        "toggle" : True
    })
    gui.add(config, "number", 0, 200).name("Number")
    gui.add(config, "text").name("Text")
    gui.add(config, "toggle").name("Toggle")

def draw():
    background(220)
    textAlign(CENTER,CENTER)
    textSize(20)
    text (f"number: {config.number}\n"+
          f"text:   {config.text}\n"+
          f"toggle: {config.toggle}", 200, 200)
