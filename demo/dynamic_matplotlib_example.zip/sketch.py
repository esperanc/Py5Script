import matplotlib.pyplot as plt
import numpy as np
import io, base64

_img = None  # guarda o p5.Image após carregamento

def matplotlib_to_p5image(fig):
    """Converte uma figura matplotlib em p5.Image via Data URL base64."""
    buf = io.BytesIO()
    fig.savefig(buf, format="png", bbox_inches="tight")
    buf.seek(0)
    b64 = base64.b64encode(buf.read()).decode("utf-8")
    data_url = f"data:image/png;base64,{b64}"
    plt.close(fig)
    return data_url
    
def update_plot():
    global fig, ax
    
    x = np.random.randn(100)
    y = np.random.randn(100)
    
    ax.scatter(x, y, alpha=0.5, color='blue')
    ax.set_title("Random Scatter Plot")

    # Converte para Data URL e carrega como p5.Image
    data_url = matplotlib_to_p5image(fig)

    # loadImage é assíncrono: usa callback para guardar a imagem
    def on_loaded(p5img):
        global _img
        _img = p5img

    P5.loadImage(data_url, create_proxy(on_loaded))


def setup():
    global _img
    create_canvas(640, 480)

    # Gera figura matplotlib
    global fig, ax
    fig, ax = plt.subplots(figsize=(6, 4), dpi=100)
    update_plot()
    
def mouse_pressed():
    update_plot()
    
def draw():
    background(240)
    if _img is not None:
        # Desenha a imagem no canvas p5 na posição (0,0)
        image(_img, 0, 0, width, height)