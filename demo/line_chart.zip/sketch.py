from line_chart import LineChart

chart = None

def setup():
    global chart
    create_canvas(700, 450)

    # Series 1: sine wave
    sine_pts = [
        createVector(x * 0.1, sin(x * 0.1))
        for x in range(0, 63)
    ]

    # Series 2: cosine wave
    cos_pts = [
        createVector(x * 0.1, cos(x * 0.1))
        for x in range(0, 63)
    ]

    # Series 3: damped sine
    damped_pts = [
        createVector(x * 0.1, sin(x * 0.1) * exp(-x * 0.03))
        for x in range(63)
    ]

    # ── Create and configure the chart ───────────────────────────────── #
    chart = LineChart(x=10, y=10, w=680, h=430)

    chart.set_title("Trigonometric Functions")
    chart.set_x_label("x")
    chart.set_y_label("f(x)")
    chart.set_x_ticks(7)
    chart.set_y_ticks(6)

    chart.add_series(sine_pts,   label="sin(x)")
    chart.add_series(cos_pts,    label="cos(x)")
    chart.add_series(damped_pts, label="sin(x)·e⁻⁰·⁰³ˣ")

    chart.set_show_grid(True)
    chart.set_show_points(False)   # too many points — skip dots
    chart.set_stroke_weight(3)


def draw():
    background(245)
    chart.draw()