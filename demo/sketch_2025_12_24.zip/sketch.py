"""
Alexandre Villares
Sketch a day for 12/24/2025 ported to Py5Script
See https://github.com/villares/sketch-a-day/tree/main/2025/sketch_2025_12_24
"""

import numpy as np
from random import shuffle, randint

NBS = [  # the possible jumps (neighbors)
    (-1, 0), (1, 0), (0, -1), (0, 1),
    (1, 1), (1, -1), (-1, 1), (-1, -1)
    ]
STEP = 16 # scale factor, distance between nodes
LIMIT = 25 # limit size of graph, allows pos smaller than width / 2 / STEP 
# START = [ (5, 5), (-5, 5), (5, -5), (-5, -5)]

grid = {}  # the nodes dict key_pos_tuple: value_origin_tuple  
to_check = []  # the growing nodes
paths = []
seed = 4
rotation = 0
rotation_on = False

def setup():
    createCanvas (800, 800, WEBGL)
    color_mode(HSB)
    generate()
    
def generate():
    global start
    random_seed(seed)
    grid.clear()
    start = [(randint(-20, 20),
              randint(-20, 20))
             for _ in range(10)]
    to_check[:] = start
    while to_check:
        #shuffle(to_check)
        new_to_check = []
        nbs =  NBS[:]
        shuffle(nbs)
        shuffle(to_check)
        while to_check:
            i, j = to_check.pop()
            for ni, nj in nbs[:6]:
                ti, tj = i + ni, j - nj  # target neighbor
                if (abs(ti) < LIMIT and abs(tj) < LIMIT
                    and (ti, tj) not in grid):
                    grid[ti, tj] = (i, j)
                    new_to_check.append((ti, tj))
        to_check[:] = new_to_check
    calc_paths()
    


def dist_origin(t):
    return dist(*t, 0, 0)

def calc_paths():
    # WIP: I think this is not working right yet
    paths.clear()
    visited = set()
    for node in sorted(grid.keys(),
                       key=dist_origin,
                       reverse=True):
        if node not in visited:
            z = 0
            visited.add(node)
            paths.append([node + (0,)])
            while node not in start:
                node = grid[node]
                visited.add(node)
                paths[-1].append(node + (z,))
                z += 1
    paths.sort(key=len)
    print(f'paths: {len(paths)}')

def draw():
    ortho()
    orbit_control()
    global rotation
    background(0)
    stroke_weight(3)
    no_fill()
    translate(0, 0, 0)
    rotate_x(radians(rotation))
    if rotation_on:
        rotation += 1
    for path in paths:
        translate(0, 0, 0.05)
        edges = np.array(path)
        stroke(len(path)* 10, 200, 255, 255)
        push()
        begin_shape()
        translate(0, 0, -len(path) * STEP)
        for x,y,z in (edges * STEP).tolist():
            vertex(x,y,z)
        end_shape()
        pop()
        
def key_pressed():
    global seed, rotation_on
    if key == 'p':
        save('frame.png')
    elif key == 'r':
        rotation_on = not rotation_on
    elif key == ' ':
        seed += 1
        generate()
    