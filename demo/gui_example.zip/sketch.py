from gui_utils import guiBlock 

def setup():
    createCanvas(400, 400)
    global gui 
    gui = guiBlock("test")
    gui.addNumber("x",0,400,50,1)
    gui.addNumber("y",0,400,50,1)
    gui.addText("text","some text")
    gui.addColor("fill","#ffffff")
    gui.addCheckbox("stroke",True)
    gui.addSelect("shape",["square","circle","triangle"],"square")
    

def draw():
    background(220)
    fill(gui.data["fill"])
    x,y=gui.data["x"], gui.data["y"]
    if gui.data["stroke"]: stroke("black") 
    else: noStroke()
    if gui.data["shape"] == "circle":
        ellipse(x,y, 50, 50)
    elif gui.data["shape"] == "triangle":
        triangle(x-25,y+25,x+25,y+25,x,y-25)
    else:
        square(x-25,y-25,50)
    textAlign(CENTER,CENTER)
    fill(0)
    noStroke()
    text(gui.data["text"],x,y)

