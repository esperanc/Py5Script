precision highp float;

uniform vec2 iResolution;
uniform float iTime;

uniform float fractal; // Which fractal to render
uniform vec3 rblend; // Reflection color blending

const int MAX_MARCHING_STEPS = 255;
const float MAX_DIST = 100.0;
const float EPSILON = 0.0001;

uniform vec3 eye; // Position of the eye
const vec3 center = vec3(0., 0., 0.); // Center of scene
const vec3 up = vec3 (0., 1., 0.); // World up vector
const float flen = 1.0;   // Focus (dist from proj plane to eye)

uniform samplerCube uCubemap; // cubemap texture

float sphereSDF(vec3 p, float r) {
    return length(p) - r;
}

float blockSDF(vec3 pt, vec3 b) {
     vec3 box = abs(pt) - b;
    return length(max(box, 0.0)) + min(max(box.x, max(box.y, box.z)), 0.0);
}


float sierpinskiPyramid(vec3 pt) {
    float r;
    float offset = 1.;
    float scale = 2.;
    const int n = 8;
    for (int i =0; i < n; i++) {
        if(pt.x + pt.y < 0.) pt.xy = -pt.yx;
        if(pt.x + pt.z < 0.) pt.xz = -pt.zx;
        if(pt.y + pt.z < 0.) pt.zy = -pt.yz;
        pt = pt * scale - offset;
    }
    
    return (sphereSDF(pt,2.) * pow(scale, -float(n)));
}

float mengerSponge(vec3 pt) {
    float scale = 1.0;
    float iterations = 3.;

    float dist = blockSDF(pt, vec3(scale));
    
    float s = 1.;
    
    float da, db, dc;
    
    for(int i = 0; i < 4; i++) {
        vec3 a = mod(pt * s, 2.0) - 1.0;
        s *= iterations;
        vec3 r = abs(1.0 - 3.0*abs(a));
        
        da = max(r.x, r.y);
        db = max(r.y, r.z);
        dc = max(r.z, r.x);
        
        float c = (min(da, min(db, dc)) - 1.) / s;
        if ( c > dist) dist = c;
    }
    
    return dist;
}

mat4 rotationMatrix(vec3 axis, float angle) {
    axis = normalize(axis);
    float s = sin(angle);
    float c = cos(angle);
    float oc = 1.0 - c;
    
    return mat4(oc * axis.x * axis.x + c,           oc * axis.x * axis.y - axis.z * s,  oc * axis.z * axis.x + axis.y * s,  0.0,
                oc * axis.x * axis.y + axis.z * s,  oc * axis.y * axis.y + c,           oc * axis.y * axis.z - axis.x * s,  0.0,
                oc * axis.z * axis.x - axis.y * s,  oc * axis.y * axis.z + axis.x * s,  oc * axis.z * axis.z + c,           0.0,
                0.0,                                0.0,                                0.0,                                1.0);
}

vec3 rotatePt(vec3 pt, vec3 axis, float angle) {
	mat4 m = rotationMatrix(axis, angle);
	return (m * vec4(pt, 1.0)).xyz;
}

float evolvingFractal(vec3 pt) {
    vec3 off = vec3(1.);
    float scale = 2.;
    const int n = 9;

    for (int i = 0; i < n; i++) {
        //pt = rotatePt(pt, vec3(1.), 31.); // snowflake
        pt = rotatePt(pt, vec3(1), cos(10.+iTime*0.13));
        
        pt = abs(pt); // for cube
        
        if(pt.x + pt.y < 0.) pt.xy = -pt.yx;
        if(pt.x + pt.z < 0.) pt.xz = -pt.zx;
        if(pt.y + pt.z < 0.) pt.zy = -pt.yz;
          
        pt = rotatePt(pt, vec3(0.35,0.2,0.3), -90.+iTime*0.12);
        
        pt.x = pt.x * scale - off.x*(scale - 1.0);
        pt.y = pt.y * scale - off.y*(scale - 1.0);
        pt.z = pt.z * scale - off.z*(scale - 1.0);
        
        pt = rotatePt(pt, vec3(0.3,0.1,0.25), -70.+iTime*0.1);
    }
    //return (sphereSDF(pt,3.) * pow(scale, -float(n)));
    return (length(pt) * pow(scale, -float(n)))-0.01;
}

float evolvingFractal2(vec3 pt) {
    vec3 off = vec3(1.25);
    float scale = 2.;
    const int n = 9;

    for (int i = 0; i < n; i++) {
        //pt = rotatePt(pt, vec3(1.), 31.); // snowflake
        pt = rotatePt(pt, vec3(1.), sin(0.+iTime*0.1));
        
        pt = abs(pt); // for cube
        
        if(pt.x + pt.y < 0.) pt.xy = -pt.yx;
        if(pt.x + pt.z < 0.) pt.xz = -pt.zx;
        if(pt.y + pt.z < 0.) pt.zy = -pt.yz;
          
        pt = rotatePt(pt, vec3(0.35,0.2,0.3), -90.+iTime*0.11);
        
        pt.x = pt.x * scale - off.x*(scale - 1.0);
        pt.y = pt.y * scale - off.y*(scale - 1.0);
        pt.z = pt.z * scale - off.z*(scale - 1.0);
        
        pt = rotatePt(pt, vec3(0.3,0.1,0.25), -70.+iTime*0.12);
        
    }
    //return (blockSDF(pt,vec3(1.)) * pow(scale, -float(n)));
    return (length(pt) * pow(scale, -float(n)))-0.01;
}
//
// From https://www.shadertoy.com/view/MlsfR4
//
void pR(inout vec2 p, float a) {
	p = cos(a)*p + sin(a)*vec2(p.y, -p.x);
}

float length6( vec3 p )
{
	p = p*p*p; p = p*p;
	return pow( p.x + p.y + p.z, 1.0/6.0 );
}

float julia(vec3 p)
{
    const float s = 10.;
    p *= s;
    
   	float len = length(p);
    p=p.yxz;

    float scale = 1.25;
    const int iterations = 28;
    float a = iTime;
	float l = 0.;
    
    vec2 rotationAnimAmp = vec2(0.05,0.04);
	vec2 rotationPhase = vec2(.45 + sin(iTime*0.5 + len*0.4) * 0.025,0.15 + cos(-0.2+iTime*2. + len*0.2) * 0.05);
	
    // vec3 juliaOffset = vec3(-3.,-1.15,-.5);
    //vec3 juliaOffset = vec3(-3.,-1.15+sin(iTime*0.2)*0.5,-.5);
    vec3 juliaOffset = vec3(-2.+cos(iTime*0.1)*0.3,-0.55-cos(iTime*0.12)*0.4,-.8);
    //vec3 juliaOffset = vec3(-3.,+0.55,-1.8);
    //vec3 juliaOffset = vec3(-1.,+0.2,-.18);
    
    pR(p.xy,.5+sin(-0.25+iTime*4.)*0.1);
    
    for (int i=0; i<iterations; i++) {
		p = abs(p);
        // scale and offset the position
		p = p*scale + juliaOffset;
        
        // Rotate the position
        pR(p.xz,rotationPhase.x*3.14 + cos(iTime*2.2 + len)*rotationAnimAmp.y);
		pR(p.yz,rotationPhase.y*3.14 + sin(iTime*2. + len)*rotationAnimAmp.x);		
        l=length6(p);
	}
	return (l*pow(scale, -float(iterations))-.25)/s;
}


float sceneSDF(vec3 p) {
    if (fractal == 0.0) return sierpinskiPyramid(p);
    if (fractal == 1.0) return mengerSponge(p);
    if (fractal == 2.0) return evolvingFractal(p);
    if (fractal == 3.0) return evolvingFractal2(p);
    if (fractal == 4.0) return julia(p);
}

vec3 normal(vec3 p) {
    float d = sceneSDF(p);
    vec2 e = vec2(0., 0.001);
    return normalize(vec3(d)-
                    vec3(sceneSDF(p-e.yxx),
                         sceneSDF(p-e.xyx),
                         sceneSDF(p-e.xxy)));
}

const vec3 lightPos = vec3(10);  // Light position
const vec3 lightColor = vec3 (1); // Light color
const vec3 matColor = vec3 (1,1,1); // material Color
const float matDiff = 0.8; // Diffuse coefficient
const float matAmb = 0.3; // Ambient coefficient
const float matSpec = 0.8; // Specular coefficient
const float matShine = 20.0; // Shininess power
const float refrIndex = 1.2; // Refraction index



float rayMarch (vec3 eye, vec3 dir, float sign) {
  float depth = 0.;
  for (int i = 0; i < MAX_MARCHING_STEPS; i++) {
    float dist = sign * sceneSDF(eye + depth * dir);
    if (dist < EPSILON) return depth;
    depth += dist;
    if (depth >= MAX_DIST) return MAX_DIST;
  }
  return MAX_DIST;
}

vec3 lighting (vec3 eye, vec3 p) {
    vec3 n = normal(p);
    vec3 l = normalize(lightPos - p);
    vec3 e = normalize(eye - p);
    vec3 ia = matAmb * lightColor * matColor;
    vec3 id = matDiff * max(0.,dot(l, n)) * lightColor * matColor;
    vec3 r = reflect(-l,n);
    vec3 is = matSpec * pow(max(0., dot(e,r)),matShine) * lightColor;
    vec3 R = reflect(-e,n);
    vec3 T = textureCube(uCubemap, R*vec3(-1,1,1)).rgb; // Flip x
    vec3 C = (ia+id+is);
    return T * rblend.x + C*rblend.y + T*C*rblend.z;
}


vec3 rayDirection(vec2 fragCoord) {
    
  vec2 uv = fragCoord.xy / iResolution.xy - 0.5 ; // Normalized coordinates
  uv.x *= iResolution.x / iResolution.y; // Aspect ratio

  vec3 Z = normalize(eye - center); // Vector center-eye
  vec3 X = normalize(cross(up,Z));  // Vector to right of proj plane
  vec3 Y = normalize(cross(Z,X));  // Vector to top of proj plane
  vec3 C = eye - flen*Z; // Center of projection plane
  vec3 P = C + X*uv.x + Y*uv.y; // Point on proj plane
  return normalize (P - eye);
}


void main( )
{
  vec3 dir = rayDirection(gl_FragCoord.xy);
  vec3 color = textureCube(uCubemap, dir*vec3(-1,1,1)).rgb; // Flip x
  float dist = rayMarch(eye, dir, 1.);
  float hit = step(dist, MAX_DIST - EPSILON);
  vec3 p = eye+dist*dir;
  gl_FragColor = vec4(hit*lighting(eye, p)+(1.-hit)*color, 1.0);
}