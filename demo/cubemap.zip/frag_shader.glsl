precision mediump float;
varying vec3 vCoords;
uniform samplerCube uCubemap;

void main() {
  gl_FragColor = textureCube(uCubemap, vCoords);
}