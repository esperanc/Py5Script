def preload():
    global my_shader
    my_shader = loadShader(
        "vertex_shader.glsl",
        "frag_shader.glsl")
    global cubemapImages
    urls = [
    	'posx.jpeg', 'negx.jpeg', 
    	'posy.jpeg', 'negy.jpeg', 
    	'posz.jpeg', 'negz.jpeg'
    ]
    cubemapImages = [loadImage(url) for url in urls]

def setup():
    createCanvas(windowWidth, windowHeight, WEBGL)
    global cubemap
    cubemap = createCubeMap()
    
def createCubeMap():
    """ Create cubemap from images """
    gl = drawingContext; 
    tex = gl.createTexture();
    gl.bindTexture(gl.TEXTURE_CUBE_MAP, tex)
    targets = [
        gl.TEXTURE_CUBE_MAP_POSITIVE_X, gl.TEXTURE_CUBE_MAP_NEGATIVE_X,
        gl.TEXTURE_CUBE_MAP_POSITIVE_Y, gl.TEXTURE_CUBE_MAP_NEGATIVE_Y,
        gl.TEXTURE_CUBE_MAP_POSITIVE_Z, gl.TEXTURE_CUBE_MAP_NEGATIVE_Z
    ]

    for img,target in zip(cubemapImages,targets):
        gl.bindTexture(gl.TEXTURE_CUBE_MAP, tex)
        # the actual image element is in img.canvas
        gl.texImage2D(target, 0, gl.RGBA, gl.RGBA, gl.UNSIGNED_BYTE, img.canvas)
        gl.generateMipmap(gl.TEXTURE_CUBE_MAP);
        
    gl.texParameteri(gl.TEXTURE_CUBE_MAP, gl.TEXTURE_MIN_FILTER, gl.LINEAR_MIPMAP_LINEAR)
    return tex

def draw():
    background(220)
    noStroke()

    shader(my_shader)

    # Vincula a textura manualmente ao slot 0
    gl = drawingContext
    gl.activeTexture(gl.TEXTURE0)
    gl.bindTexture(gl.TEXTURE_CUBE_MAP, cubemap)
    
    # p5 não entende cubemaps. Uniforme tem que ser
    # setado manualmente
    uCubemapLoc = gl.getUniformLocation(my_shader._glProgram, 'uCubemap')
    gl.uniform1i(uCubemapLoc, 0)
    
    orbitControl()
    rotateX(PI) # orientação P5 é y para baixo
    box(800)
    
