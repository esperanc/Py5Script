attribute vec3 aPosition;
varying vec3 vCoords;

uniform mat4 uProjectionMatrix;
uniform mat4 uModelViewMatrix;

void main() {
  vCoords = aPosition;
  // Removemos a translação da matriz para que o skybox não saia do lugar
  mat4 viewMatrix = uModelViewMatrix;
  viewMatrix[3] = vec4(0.0, 0.0, 0.0, 1.0);
  gl_Position = uProjectionMatrix * viewMatrix * vec4(aPosition, 1.0);
}