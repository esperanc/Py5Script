def preload():
    global img
    img = load_image("zerbini.jpg")

def setup():
    create_canvas(windowWidth, windowHeight)
    global x,y,w,h
    margin = 0.1
    if img.width/img.height > width/height:
        x = width * margin
        w = width * (1 - margin*2)
        s = w/img.width
        h = img.height * s
        y = (height - h) / 2
    else:
        y = height * margin
        h = height * (1 - margin*2)
        s = h/img.height
        w = img.width * s
        x = (width - w) / 2

def draw():
    clear()
    image(img, x, y, w, h)
